import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import ProductsPage from "@/react-app/pages/Products";
import ProfilePage from "@/react-app/pages/Profile";
import LoginPage from "@/react-app/pages/Login";
import AdminLoginPage from "@/react-app/pages/Admin";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import OrdersPage from "@/react-app/pages/Orders";
import PaymentPage from "@/react-app/pages/Payment";

// Admin Pages
import AdminDashboard from "@/react-app/pages/admin/Dashboard";
import AdminProducts from "@/react-app/pages/admin/Products";
import AddProduct from "@/react-app/pages/admin/AddProduct";
import AdminOrders from "@/react-app/pages/admin/Orders";
import AdminSessions from "@/react-app/pages/admin/Sessions";
import AdminSettings from "@/react-app/pages/admin/Settings";

export default function App() {
  return (
    <Router>
      <Routes>
        {/* User Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/payment/:productId" element={<PaymentPage />} />
        <Route path="/auth/callback" element={<AuthCallbackPage />} />

        {/* Admin Routes */}
        <Route path="/admin" element={<AdminLoginPage />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/products" element={<AdminProducts />} />
        <Route path="/admin/products/add" element={<AddProduct />} />
        <Route path="/admin/orders" element={<AdminOrders />} />
        <Route path="/admin/sessions" element={<AdminSessions />} />
        <Route path="/admin/settings" element={<AdminSettings />} />
      </Routes>
    </Router>
  );
}
