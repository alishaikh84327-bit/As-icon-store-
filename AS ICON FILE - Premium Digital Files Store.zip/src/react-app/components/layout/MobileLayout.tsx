import { ReactNode, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import { Home, ShoppingBag, User, Menu, X, LogOut, LogIn, Shield, Package } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";

interface MobileLayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
  showHeader?: boolean;
  title?: string;
}

export default function MobileLayout({
  children,
  showBottomNav = true,
  showHeader = true,
  title,
}: MobileLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, redirectToLogin } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/products", icon: ShoppingBag, label: "Products" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  const isActive = (path: string) => {
    if (path === "/" && location.pathname === "/") return true;
    if (path !== "/" && location.pathname.startsWith(path)) return true;
    return false;
  };

  const handleLogout = async () => {
    setMenuOpen(false);
    await logout();
    navigate("/");
  };

  return (
    <div className="h-full flex flex-col bg-black overflow-hidden">
      {/* Header */}
      {showHeader && (
        <header className="glass-strong safe-top flex-shrink-0 z-50">
          <div className="flex items-center justify-between px-4 h-14">
            <h1
              className="text-lg font-bold tracking-wider"
              style={{ fontFamily: "Orbitron, sans-serif" }}
            >
              {title || "AS ICON FILE"}
            </h1>
            <button
              onClick={() => setMenuOpen(true)}
              className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all duration-300"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </header>
      )}

      {/* Main Content */}
      <main
        className={`flex-1 overflow-y-auto overflow-x-hidden no-scrollbar ${
          showBottomNav ? "pb-20" : ""
        }`}
      >
        {children}
      </main>

      {/* Bottom Navigation */}
      {showBottomNav && (
        <nav className="glass-strong safe-bottom fixed bottom-0 left-0 right-0 z-50">
          <div className="flex items-center justify-around h-16 px-4">
            {navItems.map((item) => {
              const active = isActive(item.path);
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`flex flex-col items-center justify-center gap-1 px-6 py-2 rounded-2xl transition-all duration-300 ${
                    active
                      ? "bg-blue-500/20 glow-blue-sm"
                      : "hover:bg-white/5"
                  }`}
                >
                  <item.icon
                    className={`w-6 h-6 transition-all duration-300 ${
                      active ? "text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]" : "text-gray-400"
                    }`}
                  />
                  <span
                    className={`text-xs font-medium transition-all duration-300 ${
                      active ? "text-blue-400" : "text-gray-500"
                    }`}
                  >
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      {/* Side Menu */}
      {menuOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={() => setMenuOpen(false)}
          />
          <div className="fixed top-0 right-0 bottom-0 w-72 glass-strong z-50 slide-up">
            <div className="safe-top p-4">
              <div className="flex items-center justify-between mb-8">
                <h2
                  className="text-xl font-bold tracking-wider"
                  style={{ fontFamily: "Orbitron, sans-serif" }}
                >
                  Menu
                </h2>
                <button
                  onClick={() => setMenuOpen(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all duration-300"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Info */}
              {user && (
                <div className="mb-6 p-4 rounded-2xl glass">
                  <div className="flex items-center gap-3">
                    {user.google_user_data?.picture ? (
                      <img
                        src={user.google_user_data.picture}
                        alt={user.google_user_data?.name || "User"}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                        <span className="text-lg font-bold text-blue-400">
                          {user.google_user_data?.name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
                        </span>
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold truncate">{user.google_user_data?.name || user.email.split("@")[0]}</p>
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {user && (
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      navigate("/orders");
                    }}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl glass hover:bg-white/10 transition-all duration-300"
                  >
                    <Package className="w-5 h-5 text-purple-400" />
                    <span className="font-medium">My Orders</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    setMenuOpen(false);
                    navigate("/admin");
                  }}
                  className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl glass hover:bg-white/10 transition-all duration-300"
                >
                  <Shield className="w-5 h-5 text-blue-400" />
                  <span className="font-medium">Admin Login</span>
                </button>

                {user ? (
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl glass hover:bg-white/10 transition-all duration-300"
                  >
                    <LogOut className="w-5 h-5 text-red-400" />
                    <span className="font-medium">Logout</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      redirectToLogin();
                    }}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl glass hover:bg-white/10 transition-all duration-300"
                  >
                    <LogIn className="w-5 h-5 text-green-400" />
                    <span className="font-medium">Login</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
