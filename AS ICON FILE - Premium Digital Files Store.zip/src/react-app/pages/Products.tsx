import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { ShoppingBag, FileArchive, Smartphone, Code, Globe, Package } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";
import MobileLayout from "@/react-app/components/layout/MobileLayout";

interface Product {
  id: number;
  name: string;
  description: string | null;
  type: string;
  price: number;
  image_url: string | null;
}

const getTypeIcon = (type: string) => {
  switch (type) {
    case "ZIP":
      return FileArchive;
    case "APK":
      return Smartphone;
    case "HTML":
      return Code;
    case "WEBSITE LINK":
      return Globe;
    default:
      return ShoppingBag;
  }
};

const getTypeColor = (type: string) => {
  switch (type) {
    case "ZIP":
      return "text-yellow-400 bg-yellow-400/10";
    case "APK":
      return "text-green-400 bg-green-400/10";
    case "HTML":
      return "text-orange-400 bg-orange-400/10";
    case "WEBSITE LINK":
      return "text-purple-400 bg-purple-400/10";
    default:
      return "text-blue-400 bg-blue-400/10";
  }
};

export default function ProductsPage() {
  const navigate = useNavigate();
  const { user, redirectToLogin } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch("/api/products");
      const data = await res.json();
      setProducts(data);
    } catch (error) {
      console.error("Error fetching products:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleBuy = (productId: number) => {
    if (!user) {
      redirectToLogin();
      return;
    }
    navigate(`/payment/${productId}`);
  };

  return (
    <MobileLayout title="Products">
      <div className="px-4 py-6">
        {/* Header */}
        <div className="mb-6 fade-in">
          <h2 className="text-2xl font-bold mb-2">All Products</h2>
          <p className="text-gray-500 text-sm">
            Browse our premium digital files
          </p>
        </div>

        {/* Products */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-10 h-10 border-3 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20 fade-in">
            <div className="w-20 h-20 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-4">
              <Package className="w-10 h-10 text-gray-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No products yet</h3>
            <p className="text-gray-500">Check back later for new products</p>
          </div>
        ) : (
          <div className="space-y-4">
            {products.map((product, index) => {
              const TypeIcon = getTypeIcon(product.type);
              const typeColorClass = getTypeColor(product.type);

              return (
                <div
                  key={product.id}
                  className="glass rounded-3xl overflow-hidden fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {/* Product Image */}
                  <div className="relative h-44 overflow-hidden">
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center">
                        <TypeIcon className="w-16 h-16 text-blue-400/50" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />

                    {/* Type Badge */}
                    <div
                      className={`absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold ${typeColorClass}`}
                    >
                      <TypeIcon className="w-3.5 h-3.5" />
                      <span>{product.type}</span>
                    </div>
                  </div>

                  {/* Product Info */}
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
                    {product.description && (
                      <p className="text-gray-500 text-sm mb-3 line-clamp-2">
                        {product.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-blue-400">
                          ₹{product.price}
                        </span>
                      </div>

                      <button
                        onClick={() => handleBuy(product.id)}
                        className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 font-medium text-sm glow-blue-sm hover:scale-105 active:scale-95 transition-all duration-300"
                      >
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
