import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Monitor, Globe, Clock } from "lucide-react";

interface Session {
  id: number;
  device_info: string;
  browser: string;
  ip_address: string;
  created_at: string;
}

export default function AdminSessions() {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const isAdmin = sessionStorage.getItem("adminLoggedIn");
    if (!isAdmin) {
      navigate("/admin");
      return;
    }
    fetchSessions();
  }, [navigate]);

  const fetchSessions = async () => {
    try {
      const res = await fetch("/api/admin/sessions");
      const data = await res.json();
      setSessions(data);
    } catch (error) {
      console.error("Error fetching sessions:", error);
    } finally {
      setLoading(false);
    }
  };

  const parseDeviceInfo = (userAgent: string) => {
    if (userAgent.includes("iPhone")) return "iPhone";
    if (userAgent.includes("iPad")) return "iPad";
    if (userAgent.includes("Android")) return "Android";
    if (userAgent.includes("Windows")) return "Windows PC";
    if (userAgent.includes("Mac")) return "Mac";
    if (userAgent.includes("Linux")) return "Linux";
    return "Unknown Device";
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center gap-3 px-4 h-14">
          <button
            onClick={() => navigate("/admin/dashboard")}
            className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Login Devices</h1>
        </div>
      </header>

      <div className="px-4 py-6 pb-20">
        {/* Stats */}
        <div className="glass rounded-2xl p-4 mb-6 fade-in">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Monitor className="w-7 h-7 text-blue-400" />
            </div>
            <div>
              <p className="text-3xl font-bold">{sessions.length}</p>
              <p className="text-sm text-gray-500">Total Admin Logins</p>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : sessions.length === 0 ? (
          <div className="text-center py-20">
            <Monitor className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500">No login sessions recorded</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sessions.map((session, index) => (
              <div
                key={session.id}
                className="glass rounded-2xl p-4 fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                    <Monitor className="w-6 h-6 text-cyan-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold">
                      {parseDeviceInfo(session.device_info)}
                    </h3>
                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                      <Globe className="w-4 h-4" />
                      <span>{session.browser}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                      <Clock className="w-4 h-4" />
                      <span>
                        {new Date(session.created_at).toLocaleString("en-IN")}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
