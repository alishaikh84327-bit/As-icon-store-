import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import {
  Users,
  Package,
  ShoppingCart,
  Clock,
  CheckCircle,
  XCircle,
  Plus,
  List,
  Monitor,
  Settings,
  LogOut,
  ArrowLeft,
} from "lucide-react";

interface Stats {
  totalUsers: number;
  totalProducts: number;
  totalOrders: number;
  pendingOrders: number;
  approvedOrders: number;
  rejectedOrders: number;
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if admin is logged in
    const isAdmin = sessionStorage.getItem("adminLoggedIn");
    if (!isAdmin) {
      navigate("/admin");
      return;
    }

    fetchStats();
  }, [navigate]);

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/admin/stats");
      const data = await res.json();
      setStats(data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("adminLoggedIn");
    navigate("/admin");
  };

  const statCards = [
    {
      label: "Total Users",
      value: stats?.totalUsers || 0,
      icon: Users,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
    },
    {
      label: "Total Products",
      value: stats?.totalProducts || 0,
      icon: Package,
      color: "text-green-400",
      bg: "bg-green-500/10",
    },
    {
      label: "Total Orders",
      value: stats?.totalOrders || 0,
      icon: ShoppingCart,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
    },
    {
      label: "Pending Orders",
      value: stats?.pendingOrders || 0,
      icon: Clock,
      color: "text-yellow-400",
      bg: "bg-yellow-500/10",
    },
    {
      label: "Approved Orders",
      value: stats?.approvedOrders || 0,
      icon: CheckCircle,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
    },
    {
      label: "Rejected Orders",
      value: stats?.rejectedOrders || 0,
      icon: XCircle,
      color: "text-red-400",
      bg: "bg-red-500/10",
    },
  ];

  const menuItems = [
    {
      label: "Add Product",
      icon: Plus,
      path: "/admin/products/add",
      color: "text-green-400",
    },
    {
      label: "Manage Products",
      icon: Package,
      path: "/admin/products",
      color: "text-blue-400",
    },
    {
      label: "Manage Orders",
      icon: List,
      path: "/admin/orders",
      color: "text-purple-400",
    },
    {
      label: "Login Devices",
      icon: Monitor,
      path: "/admin/sessions",
      color: "text-cyan-400",
    },
    {
      label: "Settings",
      icon: Settings,
      path: "/admin/settings",
      color: "text-gray-400",
    },
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/")}
              className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1
              className="text-lg font-bold tracking-wider"
              style={{ fontFamily: "Orbitron, sans-serif" }}
            >
              Admin Panel
            </h1>
          </div>
          <button
            onClick={handleLogout}
            className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
          >
            <LogOut className="w-5 h-5 text-red-400" />
          </button>
        </div>
      </header>

      <div className="px-4 py-6 pb-20">
        {/* Stats Grid */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Dashboard Overview</h2>
          <div className="grid grid-cols-2 gap-3">
            {statCards.map((stat, index) => (
              <div
                key={stat.label}
                className="glass rounded-2xl p-4 fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                  <stat.icon className={`w-5 h-5 ${stat.color}`} />
                </div>
                <p className="text-2xl font-bold">
                  {loading ? "-" : stat.value}
                </p>
                <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Menu Items */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
          <div className="space-y-3">
            {menuItems.map((item, index) => (
              <button
                key={item.label}
                onClick={() => navigate(item.path)}
                className="w-full glass rounded-2xl p-4 flex items-center gap-4 hover:bg-white/5 transition-all fade-in"
                style={{ animationDelay: `${(index + 6) * 0.05}s` }}
              >
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                  <item.icon className={`w-6 h-6 ${item.color}`} />
                </div>
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
