import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Check, X } from "lucide-react";

export default function AddProduct() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const [name, setName] = useState("");
  const [type, setType] = useState("ZIP");
  const [price, setPrice] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [fileUrl, setFileUrl] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          type,
          price: parseFloat(price),
          imageUrl: imageUrl || null,
          fileUrl: type !== "WEBSITE LINK" ? fileUrl : null,
          websiteUrl: type === "WEBSITE LINK" ? websiteUrl : null,
        }),
      });

      if (res.ok) {
        setSuccess(true);
        setTimeout(() => navigate("/admin/products"), 1500);
      } else {
        setError("Failed to add product");
      }
    } catch (err) {
      setError("Error adding product");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center scale-in">
          <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4 glow-blue-sm">
            <Check className="w-10 h-10 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold">Product Added!</h2>
          <p className="text-gray-500 mt-2">Redirecting...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center gap-3 px-4 h-14">
          <button
            onClick={() => navigate("/admin/products")}
            className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Add Product</h1>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="px-4 py-6 pb-20 space-y-5">
        {error && (
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-2">
            <X className="w-5 h-5" />
            {error}
          </div>
        )}

        {/* Product Name */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Product Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter product name"
            className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
            required
          />
        </div>

        {/* Product Type */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Product Type
          </label>
          <div className="grid grid-cols-2 gap-2">
            {["ZIP", "APK", "HTML", "WEBSITE LINK"].map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={`py-3 rounded-xl font-medium transition-all ${
                  type === t
                    ? "bg-blue-500 glow-blue-sm"
                    : "glass hover:bg-white/10"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Price */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Price (₹)
          </label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="Enter price"
            className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
            required
            min="0"
          />
        </div>

        {/* Image URL */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Product Image URL
          </label>
          <input
            type="url"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="https://example.com/image.jpg"
            className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
          />
        </div>

        {/* File URL or Website URL */}
        {type === "WEBSITE LINK" ? (
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Website URL
            </label>
            <input
              type="url"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              placeholder="https://example.com"
              className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
              required
            />
          </div>
        ) : (
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              File URL ({type})
            </label>
            <input
              type="url"
              value={fileUrl}
              onChange={(e) => setFileUrl(e.target.value)}
              placeholder="https://example.com/file.zip"
              className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
            />
            <p className="text-xs text-gray-500 mt-2">
              Upload your file to a cloud storage and paste the direct download URL
            </p>
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-500 font-semibold glow-blue hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 mt-8"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Adding...
            </span>
          ) : (
            "Add Product"
          )}
        </button>
      </form>
    </div>
  );
}
