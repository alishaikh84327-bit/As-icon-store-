import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import {
  ArrowLeft,
  Clock,
  CheckCircle,
  XCircle,
  Image,
  ExternalLink,
} from "lucide-react";

interface Order {
  id: number;
  user_name: string;
  user_email: string;
  product_name: string;
  price: number;
  utr_number: string;
  screenshot_url: string | null;
  status: string;
  created_at: string;
}

export default function AdminOrders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    const isAdmin = sessionStorage.getItem("adminLoggedIn");
    if (!isAdmin) {
      navigate("/admin");
      return;
    }
    fetchOrders();
  }, [navigate]);

  const fetchOrders = async () => {
    try {
      const res = await fetch("/api/admin/orders");
      const data = await res.json();
      setOrders(data);
    } catch (error) {
      console.error("Error fetching orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id: number, status: string) => {
    try {
      await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      setOrders(
        orders.map((o) => (o.id === id ? { ...o, status } : o))
      );
      setSelectedOrder(null);
    } catch (error) {
      console.error("Error updating order:", error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processing":
        return "text-yellow-400 bg-yellow-500/10";
      case "approved":
        return "text-green-400 bg-green-500/10";
      case "rejected":
        return "text-red-400 bg-red-500/10";
      default:
        return "text-gray-400 bg-gray-500/10";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processing":
        return Clock;
      case "approved":
        return CheckCircle;
      case "rejected":
        return XCircle;
      default:
        return Clock;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center gap-3 px-4 h-14">
          <button
            onClick={() => navigate("/admin/dashboard")}
            className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Orders</h1>
        </div>
      </header>

      <div className="px-4 py-6 pb-20">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <Clock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500">No orders yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((order, index) => {
              const StatusIcon = getStatusIcon(order.status);
              return (
                <div
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className="glass rounded-2xl p-4 fade-in cursor-pointer hover:bg-white/5 transition-all"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold">{order.product_name}</h3>
                      <p className="text-sm text-gray-500">{order.user_name}</p>
                    </div>
                    <span
                      className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${getStatusColor(
                        order.status
                      )}`}
                    >
                      <StatusIcon className="w-3 h-3" />
                      {order.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">UTR: {order.utr_number}</span>
                    <span className="text-green-400 font-semibold">
                      ₹{order.price}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <>
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={() => setSelectedOrder(null)}
          />
          <div className="fixed bottom-0 left-0 right-0 glass-strong rounded-t-3xl z-50 p-6 max-h-[80vh] overflow-y-auto slide-up">
            <div className="w-12 h-1 bg-gray-600 rounded-full mx-auto mb-6" />

            <h2 className="text-xl font-bold mb-4">Order Details</h2>

            <div className="space-y-4">
              <div className="glass rounded-2xl p-4">
                <p className="text-sm text-gray-500">Customer</p>
                <p className="font-semibold">{selectedOrder.user_name}</p>
                <p className="text-sm text-gray-400">{selectedOrder.user_email}</p>
              </div>

              <div className="glass rounded-2xl p-4">
                <p className="text-sm text-gray-500">Product</p>
                <p className="font-semibold">{selectedOrder.product_name}</p>
                <p className="text-green-400 font-semibold">₹{selectedOrder.price}</p>
              </div>

              <div className="glass rounded-2xl p-4">
                <p className="text-sm text-gray-500">UTR Number</p>
                <p className="font-mono font-semibold">{selectedOrder.utr_number}</p>
              </div>

              <div className="glass rounded-2xl p-4">
                <p className="text-sm text-gray-500">Order Date</p>
                <p className="font-semibold">
                  {new Date(selectedOrder.created_at).toLocaleString("en-IN")}
                </p>
              </div>

              {selectedOrder.screenshot_url && (
                <div className="glass rounded-2xl p-4">
                  <p className="text-sm text-gray-500 mb-2">Payment Screenshot</p>
                  <a
                    href={selectedOrder.screenshot_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-blue-400"
                  >
                    <Image className="w-5 h-5" />
                    View Screenshot
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              )}

              {/* Action Buttons */}
              {selectedOrder.status === "processing" && (
                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => updateStatus(selectedOrder.id, "approved")}
                    className="flex-1 py-4 rounded-2xl bg-green-500 font-semibold hover:bg-green-600 transition-all"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => updateStatus(selectedOrder.id, "rejected")}
                    className="flex-1 py-4 rounded-2xl bg-red-500 font-semibold hover:bg-red-600 transition-all"
                  >
                    Reject
                  </button>
                </div>
              )}

              {selectedOrder.status !== "processing" && (
                <div
                  className={`p-4 rounded-2xl text-center font-semibold ${getStatusColor(
                    selectedOrder.status
                  )}`}
                >
                  Order {selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
