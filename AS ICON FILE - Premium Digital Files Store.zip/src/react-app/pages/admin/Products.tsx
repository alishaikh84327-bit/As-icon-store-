import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import {
  ArrowLeft,
  Plus,
  Trash2,
  FileArchive,
  Smartphone,
  Code,
  Globe,
  Package,
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  type: string;
  price: number;
  image_url: string;
  created_at: string;
}

const getTypeIcon = (type: string) => {
  switch (type) {
    case "ZIP":
      return FileArchive;
    case "APK":
      return Smartphone;
    case "HTML":
      return Code;
    case "WEBSITE LINK":
      return Globe;
    default:
      return Package;
  }
};

export default function AdminProducts() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const isAdmin = sessionStorage.getItem("adminLoggedIn");
    if (!isAdmin) {
      navigate("/admin");
      return;
    }
    fetchProducts();
  }, [navigate]);

  const fetchProducts = async () => {
    try {
      const res = await fetch("/api/products");
      const data = await res.json();
      setProducts(data);
    } catch (error) {
      console.error("Error fetching products:", error);
    } finally {
      setLoading(false);
    }
  };

  const deleteProduct = async (id: number) => {
    if (!confirm("Are you sure you want to delete this product?")) return;

    try {
      await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
      setProducts(products.filter((p) => p.id !== id));
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/admin/dashboard")}
              className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-lg font-bold">Products</h1>
          </div>
          <button
            onClick={() => navigate("/admin/products/add")}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-blue-500 glow-blue-sm hover:bg-blue-600 transition-all"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </header>

      <div className="px-4 py-6 pb-20">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500">No products yet</p>
            <button
              onClick={() => navigate("/admin/products/add")}
              className="mt-4 px-6 py-3 rounded-xl bg-blue-500 font-medium glow-blue-sm"
            >
              Add First Product
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {products.map((product, index) => {
              const TypeIcon = getTypeIcon(product.type);
              return (
                <div
                  key={product.id}
                  className="glass rounded-2xl p-4 fade-in"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex gap-4">
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-20 h-20 rounded-xl object-cover"
                      />
                    ) : (
                      <div className="w-20 h-20 rounded-xl bg-white/5 flex items-center justify-center">
                        <TypeIcon className="w-8 h-8 text-gray-500" />
                      </div>
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold">{product.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400">
                          {product.type}
                        </span>
                        <span className="text-green-400 font-semibold">
                          ₹{product.price}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => deleteProduct(product.id)}
                      className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center hover:bg-red-500/20 transition-all"
                    >
                      <Trash2 className="w-5 h-5 text-red-400" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
