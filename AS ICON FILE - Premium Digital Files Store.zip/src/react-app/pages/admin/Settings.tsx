import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Save, Check } from "lucide-react";

export default function AdminSettings() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [upiId, setUpiId] = useState("");
  const [qrCodeUrl, setQrCodeUrl] = useState("");

  useEffect(() => {
    const isAdmin = sessionStorage.getItem("adminLoggedIn");
    if (!isAdmin) {
      navigate("/admin");
      return;
    }
    fetchSettings();
  }, [navigate]);

  const fetchSettings = async () => {
    try {
      const res = await fetch("/api/settings/payment");
      const data = await res.json();
      setUpiId(data.upi_id || "");
      setQrCodeUrl(data.qr_code_url || "");
    } catch (error) {
      console.error("Error fetching settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          upiId,
          qrCodeUrl,
        }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      console.error("Error saving settings:", error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/admin/dashboard")}
              className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-lg font-bold">Settings</h1>
          </div>
          <button
            onClick={saveSettings}
            disabled={saving}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-blue-500 glow-blue-sm hover:bg-blue-600 transition-all disabled:opacity-50"
          >
            {saved ? (
              <Check className="w-5 h-5" />
            ) : saving ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Save className="w-5 h-5" />
            )}
          </button>
        </div>
      </header>

      <div className="px-4 py-6 pb-20">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Payment Settings */}
            <div className="fade-in">
              <h2 className="text-lg font-semibold mb-4">Payment Settings</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    UPI ID
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="yourname@upi"
                    className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    QR Code Image URL
                  </label>
                  <input
                    type="url"
                    value={qrCodeUrl}
                    onChange={(e) => setQrCodeUrl(e.target.value)}
                    placeholder="https://example.com/qr-code.png"
                    className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    Upload your UPI QR code image and paste the direct URL here
                  </p>
                </div>

                {qrCodeUrl && (
                  <div className="glass rounded-2xl p-4">
                    <p className="text-sm text-gray-500 mb-3">QR Preview</p>
                    <img
                      src={qrCodeUrl}
                      alt="QR Code"
                      className="w-48 h-48 mx-auto rounded-xl object-contain bg-white"
                    />
                  </div>
                )}
              </div>
            </div>

            {saved && (
              <div className="p-4 rounded-2xl bg-green-500/10 border border-green-500/20 text-green-400 text-center font-medium fade-in">
                Settings saved successfully!
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
