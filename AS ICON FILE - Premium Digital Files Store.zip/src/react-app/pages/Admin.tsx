import { useState } from "react";
import { useNavigate } from "react-router";
import { Shield, User, Lock, ArrowLeft, Eye, EyeOff } from "lucide-react";
import MobileLayout from "@/react-app/components/layout/MobileLayout";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (res.ok) {
        sessionStorage.setItem("adminLoggedIn", "true");
        navigate("/admin/dashboard");
      } else {
        setError("Invalid admin credentials");
      }
    } catch (err) {
      setError("Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <MobileLayout showBottomNav={false} showHeader={false}>
      <div className="min-h-full flex flex-col px-6 py-8 safe-top">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-[80px]" />
        </div>

        {/* Back Button */}
        <button
          onClick={() => navigate("/")}
          className="relative z-10 w-12 h-12 rounded-2xl glass flex items-center justify-center hover:bg-white/10 transition-all duration-300 mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="relative z-10 flex-1 flex flex-col justify-center">
          {/* Icon */}
          <div className="flex justify-center mb-8 fade-in">
            <div className="w-24 h-24 rounded-3xl glass flex items-center justify-center glow-blue">
              <Shield className="w-12 h-12 text-blue-400" />
            </div>
          </div>

          {/* Header */}
          <div className="text-center mb-10 fade-in" style={{ animationDelay: "0.1s" }}>
            <h1
              className="text-3xl font-black tracking-wider mb-2"
              style={{ fontFamily: "Orbitron, sans-serif" }}
            >
              Admin Login
            </h1>
            <p className="text-gray-500">Access the admin dashboard</p>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-5 fade-in" style={{ animationDelay: "0.2s" }}>
            {error && (
              <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm text-center">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Username
              </label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter admin username"
                  className="w-full pl-12 pr-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all duration-300 placeholder:text-gray-600"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter admin password"
                  className="w-full pl-12 pr-12 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all duration-300 placeholder:text-gray-600"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-500 font-semibold glow-blue hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed mt-8"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Verifying...
                </span>
              ) : (
                "Login to Dashboard"
              )}
            </button>
          </form>
        </div>
      </div>
    </MobileLayout>
  );
}
