import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import {
  ArrowLeft,
  Copy,
  Check,
  Send,
  QrCode,
  AlertCircle,
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  type: string;
  price: number;
  image_url: string | null;
}

interface PaymentSettings {
  upi_id: string;
  qr_code_url: string | null;
}

export default function PaymentPage() {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [product, setProduct] = useState<Product | null>(null);
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const [utrNumber, setUtrNumber] = useState("");
  const [screenshotUrl, setScreenshotUrl] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (user === null) {
      navigate("/login");
      return;
    }
    if (user && productId) {
      fetchData();
    }
  }, [user, productId, navigate]);

  const fetchData = async () => {
    try {
      const [productRes, settingsRes] = await Promise.all([
        fetch(`/api/products/${productId}`),
        fetch("/api/settings/payment"),
      ]);
      const productData = await productRes.json();
      const settingsData = await settingsRes.json();
      setProduct(productData);
      setPaymentSettings(settingsData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyUpiId = () => {
    if (paymentSettings?.upi_id) {
      navigator.clipboard.writeText(paymentSettings.upi_id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSubmit = async () => {
    if (!utrNumber.trim()) {
      setError("Please enter the UTR number");
      return;
    }

    setSubmitting(true);
    setError("");

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: parseInt(productId!),
          utrNumber: utrNumber.trim(),
          screenshotUrl: screenshotUrl.trim() || null,
        }),
      });

      if (res.ok) {
        setSuccess(true);
        setTimeout(() => navigate("/orders"), 2000);
      } else {
        const data = await res.json();
        setError(data.error || "Failed to place order");
      }
    } catch (err) {
      setError("Error placing order. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (user === undefined || loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-6">
        <div className="text-center scale-in">
          <div className="w-24 h-24 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6 glow-blue-sm">
            <Check className="w-12 h-12 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Order Placed!</h2>
          <p className="text-gray-400">
            Your payment is being verified. You'll receive access once approved.
          </p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-gray-500">Product not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="glass-strong safe-top sticky top-0 z-50">
        <div className="flex items-center gap-3 px-4 h-14">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 flex items-center justify-center rounded-xl glass hover:bg-white/10 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Payment</h1>
        </div>
      </header>

      <div className="px-4 py-6 pb-32">
        {/* Product Summary */}
        <div className="glass rounded-2xl p-4 mb-6 fade-in">
          <div className="flex items-center gap-4">
            {product.image_url ? (
              <img
                src={product.image_url}
                alt={product.name}
                className="w-16 h-16 rounded-xl object-cover"
              />
            ) : (
              <div className="w-16 h-16 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <QrCode className="w-8 h-8 text-blue-400" />
              </div>
            )}
            <div className="flex-1">
              <h2 className="font-semibold">{product.name}</h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400">
                {product.type}
              </span>
            </div>
            <p className="text-2xl font-bold text-green-400">₹{product.price}</p>
          </div>
        </div>

        {/* Payment Instructions */}
        <div className="glass rounded-2xl p-5 mb-6 fade-in" style={{ animationDelay: "0.1s" }}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-blue-500 text-sm flex items-center justify-center">1</span>
            Pay via UPI
          </h3>

          {/* UPI ID */}
          <div className="mb-4">
            <p className="text-sm text-gray-500 mb-2">UPI ID</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 px-4 py-3 rounded-xl glass bg-white/5 font-mono text-sm">
                {paymentSettings?.upi_id || "Loading..."}
              </div>
              <button
                onClick={copyUpiId}
                className="w-12 h-12 rounded-xl glass flex items-center justify-center hover:bg-white/10 transition-all"
              >
                {copied ? (
                  <Check className="w-5 h-5 text-green-400" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* QR Code */}
          {paymentSettings?.qr_code_url && (
            <div className="text-center">
              <p className="text-sm text-gray-500 mb-3">Or scan QR code</p>
              <div className="inline-block p-3 rounded-2xl bg-white">
                <img
                  src={paymentSettings.qr_code_url}
                  alt="UPI QR Code"
                  className="w-48 h-48 object-contain"
                />
              </div>
            </div>
          )}
        </div>

        {/* UTR Number Input */}
        <div className="glass rounded-2xl p-5 mb-6 fade-in" style={{ animationDelay: "0.2s" }}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-blue-500 text-sm flex items-center justify-center">2</span>
            Enter Payment Details
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                UTR Number / Transaction ID *
              </label>
              <input
                type="text"
                value={utrNumber}
                onChange={(e) => setUtrNumber(e.target.value)}
                placeholder="Enter 12-digit UTR number"
                className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Payment Screenshot URL (Optional)
              </label>
              <input
                type="url"
                value={screenshotUrl}
                onChange={(e) => setScreenshotUrl(e.target.value)}
                placeholder="https://example.com/screenshot.jpg"
                className="w-full px-4 py-4 rounded-2xl glass bg-white/5 border-0 focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-600"
              />
              <p className="text-xs text-gray-500 mt-2">
                Upload screenshot to a cloud storage and paste URL
              </p>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-2 mb-6 fade-in">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            {error}
          </div>
        )}
      </div>

      {/* Submit Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 glass-strong safe-bottom">
        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-500 font-semibold glow-blue hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              Submit Order
            </>
          )}
        </button>
      </div>
    </div>
  );
}
