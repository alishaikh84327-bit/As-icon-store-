import { useNavigate } from "react-router";
import { Diamond, Sparkles, ChevronRight } from "lucide-react";
import MobileLayout from "@/react-app/components/layout/MobileLayout";

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <MobileLayout>
      <div className="min-h-full flex flex-col items-center justify-center px-6 py-12 relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/20 rounded-full blur-[100px]" />
          <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-blue-600/10 rounded-full blur-[80px]" />
          <div className="absolute top-1/3 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-[60px]" />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col items-center text-center">
          {/* Logo Icon */}
          <div className="relative mb-8 fade-in">
            <div className="w-32 h-32 rounded-3xl glass flex items-center justify-center glow-blue float">
              <Diamond className="w-16 h-16 text-blue-400" />
            </div>
            <div className="absolute -top-2 -right-2">
              <Sparkles className="w-8 h-8 text-blue-300 animate-pulse" />
            </div>
          </div>

          {/* Title */}
          <h1
            className="text-4xl font-black tracking-wider mb-3 glow-text fade-in"
            style={{ fontFamily: "Orbitron, sans-serif", animationDelay: "0.1s" }}
          >
            AS ICON FILE
          </h1>

          {/* Subtitle */}
          <p
            className="text-gray-400 text-lg mb-12 fade-in"
            style={{ animationDelay: "0.2s" }}
          >
            Premium Digital Files Store
          </p>

          {/* Browse Button */}
          <button
            onClick={() => navigate("/products")}
            className="group relative px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-500 font-semibold text-lg glow-blue pulse-glow transition-all duration-300 hover:scale-105 active:scale-95 fade-in flex items-center gap-3"
            style={{ animationDelay: "0.3s" }}
          >
            <span>Browse Products</span>
            <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            <div className="absolute inset-0 rounded-2xl shimmer" />
          </button>

          {/* Stats */}
          <div
            className="mt-16 grid grid-cols-3 gap-6 w-full max-w-sm fade-in"
            style={{ animationDelay: "0.4s" }}
          >
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-2xl font-bold text-blue-400">50+</p>
              <p className="text-xs text-gray-500 mt-1">Products</p>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-2xl font-bold text-blue-400">1K+</p>
              <p className="text-xs text-gray-500 mt-1">Downloads</p>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-2xl font-bold text-blue-400">24/7</p>
              <p className="text-xs text-gray-500 mt-1">Support</p>
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
