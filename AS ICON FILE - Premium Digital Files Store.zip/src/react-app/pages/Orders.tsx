import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import MobileLayout from "@/react-app/components/layout/MobileLayout";
import {
  Clock,
  CheckCircle,
  XCircle,
  Download,
  ExternalLink,
  Package,
} from "lucide-react";

interface Order {
  id: number;
  product_id: number;
  product_name: string;
  product_type: string;
  price: number;
  status: string;
  file_url: string | null;
  website_url: string | null;
  created_at: string;
}

export default function OrdersPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user === null) {
      navigate("/login");
      return;
    }
    if (user) {
      fetchOrders();
    }
  }, [user, navigate]);

  const fetchOrders = async () => {
    try {
      const res = await fetch("/api/orders");
      const data = await res.json();
      setOrders(data);
    } catch (error) {
      console.error("Error fetching orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processing":
        return "text-yellow-400 bg-yellow-500/10 border-yellow-500/20";
      case "approved":
        return "text-green-400 bg-green-500/10 border-green-500/20";
      case "rejected":
        return "text-red-400 bg-red-500/10 border-red-500/20";
      default:
        return "text-gray-400 bg-gray-500/10 border-gray-500/20";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processing":
        return Clock;
      case "approved":
        return CheckCircle;
      case "rejected":
        return XCircle;
      default:
        return Clock;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "processing":
        return "Processing";
      case "approved":
        return "Approved";
      case "rejected":
        return "Rejected";
      default:
        return status;
    }
  };

  if (user === undefined) {
    return (
      <MobileLayout title="My Orders">
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-10 h-10 border-3 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout title="My Orders">
      <div className="px-4 py-6 pb-24">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20 fade-in">
            <div className="w-20 h-20 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-4">
              <Package className="w-10 h-10 text-gray-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No orders yet</h3>
            <p className="text-gray-500 mb-6">
              Browse our products and make your first purchase
            </p>
            <button
              onClick={() => navigate("/products")}
              className="px-6 py-3 rounded-xl bg-blue-500 font-medium glow-blue-sm"
            >
              Browse Products
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order, index) => {
              const StatusIcon = getStatusIcon(order.status);
              return (
                <div
                  key={order.id}
                  className="glass rounded-2xl overflow-hidden fade-in"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold">{order.product_name}</h3>
                        <p className="text-sm text-gray-500">
                          {new Date(order.created_at).toLocaleDateString("en-IN", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                      <span className="text-green-400 font-bold">₹{order.price}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-xs px-2 py-1 rounded-full bg-blue-500/20 text-blue-400">
                        {order.product_type}
                      </span>
                      <span
                        className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full border ${getStatusColor(
                          order.status
                        )}`}
                      >
                        <StatusIcon className="w-3.5 h-3.5" />
                        {getStatusText(order.status)}
                      </span>
                    </div>
                  </div>

                  {/* Download/Access Section */}
                  {order.status === "approved" && (
                    <div className="border-t border-white/5 p-4">
                      {order.product_type === "WEBSITE LINK" && order.website_url ? (
                        <a
                          href={order.website_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-blue-500 font-medium glow-blue-sm"
                        >
                          <ExternalLink className="w-5 h-5" />
                          Open Website
                        </a>
                      ) : order.file_url ? (
                        <a
                          href={order.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          download
                          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-green-500 font-medium"
                        >
                          <Download className="w-5 h-5" />
                          Download {order.product_type}
                        </a>
                      ) : (
                        <p className="text-center text-sm text-gray-500">
                          Download link will be available soon
                        </p>
                      )}
                    </div>
                  )}

                  {order.status === "processing" && (
                    <div className="border-t border-white/5 p-4">
                      <div className="flex items-center justify-center gap-2 text-yellow-400 text-sm">
                        <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                        Payment verification in progress
                      </div>
                    </div>
                  )}

                  {order.status === "rejected" && (
                    <div className="border-t border-white/5 p-4">
                      <p className="text-center text-sm text-red-400">
                        Payment was not verified. Please contact support.
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
