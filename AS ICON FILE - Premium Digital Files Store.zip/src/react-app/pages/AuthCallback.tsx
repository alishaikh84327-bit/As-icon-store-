import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Loader2, CheckCircle, XCircle } from "lucide-react";

export default function AuthCallbackPage() {
  const navigate = useNavigate();
  const { exchangeCodeForSessionToken } = useAuth();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [error, setError] = useState("");

  useEffect(() => {
    const handleCallback = async () => {
      try {
        await exchangeCodeForSessionToken();
        setStatus("success");
        setTimeout(() => {
          navigate("/");
        }, 1500);
      } catch (err) {
        console.error("Auth callback error:", err);
        setStatus("error");
        setError("Failed to complete login. Please try again.");
        setTimeout(() => {
          navigate("/login");
        }, 2000);
      }
    };

    handleCallback();
  }, [exchangeCodeForSessionToken, navigate]);

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/20 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 text-center">
        {status === "loading" && (
          <div className="fade-in">
            <Loader2 className="w-16 h-16 text-blue-400 animate-spin mx-auto mb-6" />
            <h2 className="text-2xl font-bold mb-2">Logging you in...</h2>
            <p className="text-gray-500">Please wait while we complete the authentication</p>
          </div>
        )}

        {status === "success" && (
          <div className="scale-in">
            <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6 glow-blue-sm">
              <CheckCircle className="w-10 h-10 text-green-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Login Successful!</h2>
            <p className="text-gray-500">Redirecting to home...</p>
          </div>
        )}

        {status === "error" && (
          <div className="scale-in">
            <div className="w-20 h-20 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-6">
              <XCircle className="w-10 h-10 text-red-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Login Failed</h2>
            <p className="text-gray-500">{error}</p>
          </div>
        )}
      </div>
    </div>
  );
}
