import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";
import MobileLayout from "@/react-app/components/layout/MobileLayout";

export default function LoginPage() {
  const navigate = useNavigate();
  const { redirectToLogin, isPending, user } = useAuth();
  const [loading, setLoading] = useState(false);

  // If already logged in, redirect to home
  if (user && !isPending) {
    navigate("/");
    return null;
  }

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      await redirectToLogin();
    } catch (error) {
      console.error("Login error:", error);
      setLoading(false);
    }
  };

  return (
    <MobileLayout showBottomNav={false} showHeader={false}>
      <div className="min-h-full flex flex-col px-6 py-8 safe-top">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/20 rounded-full blur-[120px]" />
        </div>

        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="relative z-10 w-12 h-12 rounded-2xl glass flex items-center justify-center hover:bg-white/10 transition-all duration-300 mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="relative z-10 flex-1 flex flex-col justify-center">
          {/* Header */}
          <div className="text-center mb-10 fade-in">
            <h1
              className="text-3xl font-black tracking-wider mb-2"
              style={{ fontFamily: "Orbitron, sans-serif" }}
            >
              Welcome
            </h1>
            <p className="text-gray-500">Sign in to your account</p>
          </div>

          {/* Google Login Button */}
          <div className="space-y-4 fade-in" style={{ animationDelay: "0.1s" }}>
            <button
              onClick={handleGoogleLogin}
              disabled={loading || isPending}
              className="w-full py-4 rounded-2xl glass flex items-center justify-center gap-3 font-semibold hover:bg-white/10 transition-all duration-300 disabled:opacity-50"
            >
              {loading || isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </>
              )}
            </button>

            <p className="text-center text-gray-500 text-sm">
              Your account is permanently saved in the cloud.
              <br />
              Login from any device using your Google account.
            </p>
          </div>

          {/* Info */}
          <div className="mt-12 p-4 rounded-2xl glass fade-in" style={{ animationDelay: "0.2s" }}>
            <h3 className="font-semibold mb-2 text-blue-400">Real Permanent Accounts</h3>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>✓ Accounts saved forever in cloud database</li>
              <li>✓ Login from any phone or browser</li>
              <li>✓ Secure Google authentication</li>
              <li>✓ Access your orders anywhere</li>
            </ul>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
