import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Enable CORS
app.use("/*", cors());

// ==================== AUTH ENDPOINTS ====================

// Get Google OAuth redirect URL
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });
  return c.json({ redirectUrl }, 200);
});

// Exchange code for session token
app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  try {
    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error("Session exchange error:", error);
    return c.json({ error: "Failed to exchange code" }, 500);
  }
});

// Get current user
app.get("/api/users/me", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Not authenticated" }, 401);
  }

  // Upsert user in our database
  try {
    await c.env.DB.prepare(`
      INSERT INTO users (mocha_user_id, email, name, picture, updated_at)
      VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(mocha_user_id) DO UPDATE SET
        email = excluded.email,
        name = excluded.name,
        picture = excluded.picture,
        updated_at = CURRENT_TIMESTAMP
    `).bind(
      mochaUser.id,
      mochaUser.email,
      mochaUser.google_user_data?.name || mochaUser.email.split("@")[0],
      mochaUser.google_user_data?.picture || null
    ).run();
  } catch (error) {
    console.error("Error upserting user:", error);
  }

  // Get user from our database
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM users WHERE mocha_user_id = ?"
  ).bind(mochaUser.id).all();

  const dbUser = results[0];

  return c.json({
    id: mochaUser.id,
    email: mochaUser.email,
    name: mochaUser.google_user_data?.name || mochaUser.email.split("@")[0],
    picture: mochaUser.google_user_data?.picture,
    createdAt: dbUser?.created_at || mochaUser.created_at,
    dbUserId: dbUser?.id,
  });
});

// Logout
app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    try {
      await deleteSession(sessionToken, {
        apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
        apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
      });
    } catch (error) {
      console.error("Error deleting session:", error);
    }
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// ==================== PRODUCTS ENDPOINTS ====================

// Get all products
app.get("/api/products", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM products WHERE is_active = 1 ORDER BY created_at DESC"
  ).all();
  return c.json(results);
});

// Get single product
app.get("/api/products/:id", async (c) => {
  const id = c.req.param("id");
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(id).all();
  
  if (results.length === 0) {
    return c.json({ error: "Product not found" }, 404);
  }
  
  return c.json(results[0]);
});

// ==================== ORDERS ENDPOINTS ====================

// Create order (authenticated)
app.post("/api/orders", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  const body = await c.req.json();

  // Get user from database
  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(mochaUser!.id).all();

  if (userResults.length === 0) {
    return c.json({ error: "User not found" }, 404);
  }

  const userId = userResults[0].id;

  const result = await c.env.DB.prepare(`
    INSERT INTO orders (user_id, product_id, utr_number, screenshot_url, status)
    VALUES (?, ?, ?, ?, 'processing')
  `).bind(userId, body.productId, body.utrNumber, body.screenshotUrl || null).run();

  return c.json({ success: true, orderId: result.meta.last_row_id });
});

// Get user's orders (authenticated)
app.get("/api/orders", authMiddleware, async (c) => {
  const mochaUser = c.get("user");

  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(mochaUser!.id).all();

  if (userResults.length === 0) {
    return c.json([]);
  }

  const userId = userResults[0].id;

  const { results } = await c.env.DB.prepare(`
    SELECT o.*, p.name as product_name, p.price, p.type, p.file_url, p.website_url
    FROM orders o
    JOIN products p ON o.product_id = p.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
  `).bind(userId).all();

  return c.json(results);
});

// ==================== SETTINGS ENDPOINTS ====================

// Get UPI settings
app.get("/api/settings/payment", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT key, value FROM settings WHERE key IN ('upi_id', 'qr_code_url')"
  ).all();

  const settings: Record<string, string> = {};
  for (const row of results) {
    settings[row.key as string] = row.value as string;
  }

  return c.json(settings);
});

// ==================== ADMIN ENDPOINTS ====================

// Admin login
app.post("/api/admin/login", async (c) => {
  const body = await c.req.json();
  
  if (body.username === "AS" && body.password === "AS@03") {
    // Log admin session
    const userAgent = c.req.header("user-agent") || "Unknown";
    const ip = c.req.header("cf-connecting-ip") || c.req.header("x-forwarded-for") || "Unknown";
    
    // Parse browser info
    let browser = "Unknown";
    if (userAgent.includes("Chrome")) browser = "Chrome";
    else if (userAgent.includes("Firefox")) browser = "Firefox";
    else if (userAgent.includes("Safari")) browser = "Safari";
    else if (userAgent.includes("Edge")) browser = "Edge";

    await c.env.DB.prepare(`
      INSERT INTO admin_sessions (device_info, browser, ip_address)
      VALUES (?, ?, ?)
    `).bind(userAgent, browser, ip).run();

    return c.json({ success: true });
  }

  return c.json({ error: "Invalid credentials" }, 401);
});

// Admin: Get dashboard stats
app.get("/api/admin/stats", async (c) => {
  const [users, products, orders, pending, approved, rejected] = await Promise.all([
    c.env.DB.prepare("SELECT COUNT(*) as count FROM users").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM products WHERE is_active = 1").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM orders").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM orders WHERE status = 'processing'").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM orders WHERE status = 'approved'").first(),
    c.env.DB.prepare("SELECT COUNT(*) as count FROM orders WHERE status = 'rejected'").first(),
  ]);

  return c.json({
    totalUsers: users?.count || 0,
    totalProducts: products?.count || 0,
    totalOrders: orders?.count || 0,
    pendingOrders: pending?.count || 0,
    approvedOrders: approved?.count || 0,
    rejectedOrders: rejected?.count || 0,
  });
});

// Admin: Get all orders
app.get("/api/admin/orders", async (c) => {
  const { results } = await c.env.DB.prepare(`
    SELECT o.*, u.name as user_name, u.email as user_email, 
           p.name as product_name, p.price
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN products p ON o.product_id = p.id
    ORDER BY o.created_at DESC
  `).all();

  return c.json(results);
});

// Admin: Update order status
app.patch("/api/admin/orders/:id", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();

  await c.env.DB.prepare(
    "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(body.status, id).run();

  return c.json({ success: true });
});

// Admin: Add product
app.post("/api/admin/products", async (c) => {
  const body = await c.req.json();

  const result = await c.env.DB.prepare(`
    INSERT INTO products (name, description, type, price, image_url, file_url, website_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).bind(
    body.name,
    body.description || null,
    body.type,
    body.price,
    body.imageUrl || null,
    body.fileUrl || null,
    body.websiteUrl || null
  ).run();

  return c.json({ success: true, productId: result.meta.last_row_id });
});

// Admin: Delete product
app.delete("/api/admin/products/:id", async (c) => {
  const id = c.req.param("id");
  await c.env.DB.prepare(
    "UPDATE products SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(id).run();
  return c.json({ success: true });
});

// Admin: Get login sessions
app.get("/api/admin/sessions", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM admin_sessions ORDER BY created_at DESC LIMIT 50"
  ).all();
  return c.json(results);
});

// Admin: Update settings
app.patch("/api/admin/settings", async (c) => {
  const body = await c.req.json();

  if (body.upiId) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'upi_id'"
    ).bind(body.upiId).run();
  }

  if (body.qrCodeUrl !== undefined) {
    await c.env.DB.prepare(
      "UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = 'qr_code_url'"
    ).bind(body.qrCodeUrl).run();
  }

  return c.json({ success: true });
});

export default app;
