
DELETE FROM settings WHERE key IN ('upi_id', 'qr_code_url');
DROP TABLE settings;
DROP TABLE admin_sessions;
DROP INDEX idx_orders_status;
DROP INDEX idx_orders_user_id;
DROP TABLE orders;
DROP TABLE products;
DROP INDEX idx_users_email;
DROP INDEX idx_users_mocha_user_id;
DROP TABLE users;
